import UIKit

let x:Double = 100.0
let y:Double = 2.0
x+y
x-y
x/y
x*y
pow(x, y)
sqrt(x)
sin(y/x)

